#!/usr/bin/env python3
"""
MineServer Remote Agent
Легковесный агент для управления сервером Minecraft с телефона.
Работает без внешних зависимостей (только стандартная библиотека Python).
"""

import os
import sys
import json
import time
import socket
import secrets
import subprocess
import threading
from collections import deque
from http.server import HTTPServer, BaseHTTPRequestHandler

VERSION = "1.0.0"
CONFIG_FILE = "config.json"

class ServerManager:
    def __init__(self, config):
        self.config = config
        self.process = None
        self.state = "offline"  # offline, starting, online, stopping
        self.logs = deque(maxlen=200)
        self.lock = threading.Lock()
        self.start_time = None
        self.reader_thread = None

    def get_server_dir(self):
        return self.config.get("server_dir", "")

    def get_launch_file(self):
        return self.config.get("launch_file", "start.bat")

    def get_full_script_path(self):
        s_dir = self.get_server_dir()
        s_file = self.get_launch_file()
        if not s_dir:
            return s_file
        return os.path.join(s_dir, s_file)

    def start_server(self):
        with self.lock:
            if self.process is not None and self.process.poll() is None:
                return False, "Сервер уже запущен"

            script_path = self.get_full_script_path()
            server_dir = self.get_server_dir()

            if not os.path.exists(script_path):
                return False, f"Файл запуска не найден: {script_path}"

            self.state = "starting"
            self.logs.clear()
            self.logs.append(f"[{time.strftime('%H:%M:%S')}] [AGENT] Запуск сервера: {script_path}")

            try:
                # В Windows запуск .bat файлов лучше производить через shell=True или cmd.exe
                if sys.platform.startswith("win"):
                    cmd = f'"{script_path}"'
                else:
                    cmd = ["bash", script_path] if script_path.endswith(".sh") else [script_path]

                self.process = subprocess.Popen(
                    cmd,
                    cwd=server_dir if server_dir and os.path.exists(server_dir) else None,
                    stdin=subprocess.PIPE,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.STDOUT,
                    text=True,
                    bufsize=1,
                    universal_newlines=True,
                    shell=sys.platform.startswith("win")
                )
                self.start_time = time.time()
                
                # Запускаем чтение логов в отдельном потоке
                self.reader_thread = threading.Thread(target=self._read_output, daemon=True)
                self.reader_thread.start()
                return True, "Сервер успешно запускается"
            except Exception as e:
                self.state = "offline"
                self.logs.append(f"[{time.strftime('%H:%M:%S')}] [AGENT ERROR] Ошибка запуска: {e}")
                return False, f"Ошибка запуска: {str(e)}"

    def _read_output(self):
        proc = self.process
        if not proc or not proc.stdout:
            return

        for line in iter(proc.stdout.readline, ''):
            cleaned = line.rstrip('\r\n')
            if cleaned:
                self.logs.append(cleaned)
                # Определяем статус готовности сервера
                lowered = cleaned.lower()
                if "done (" in lowered or "for help, type" in lowered:
                    self.state = "online"

        proc.stdout.close()
        proc.wait()
        with self.lock:
            self.state = "offline"
            self.process = None
            self.start_time = None
            self.logs.append(f"[{time.strftime('%H:%M:%S')}] [AGENT] Процесс сервера завершён.")

    def stop_server(self, force=False):
        with self.lock:
            if self.process is None or self.process.poll() is not None:
                self.state = "offline"
                self.process = None
                return False, "Сервер не запущен"

            if force:
                self.logs.append(f"[{time.strftime('%H:%M:%S')}] [AGENT] Принудительное завершение процесса...")
                self.process.kill()
                self.state = "offline"
                self.process = None
                return True, "Сервер принудительно остановлен"

            self.state = "stopping"
            self.logs.append(f"[{time.strftime('%H:%M:%S')}] [AGENT] Отправка команды 'stop'...")
            try:
                if self.process.stdin:
                    self.process.stdin.write("stop\n")
                    self.process.stdin.flush()
                
                # Запуск таймера ожидания на случай зависания
                def wait_and_kill():
                    time.sleep(35)
                    with self.lock:
                        if self.process and self.process.poll() is None:
                            self.logs.append(f"[{time.strftime('%H:%M:%S')}] [AGENT] Сервер не ответил за 35 сек. Принудительное завершение...")
                            self.process.kill()
                            self.state = "offline"
                            self.process = None

                threading.Thread(target=wait_and_kill, daemon=True).start()
                return True, "Команда stop отправлена"
            except Exception as e:
                return False, f"Ошибка при отправке команды stop: {e}"

    def restart_server(self):
        stopped, msg = self.stop_server()
        if not stopped:
            # Если сервер и так был выключен - просто запускаем
            return self.start_server()

        def restart_worker():
            # Ждём завершения текущего процесса до 40 секунд
            for _ in range(40):
                if self.process is None:
                    break
                time.sleep(1)
            time.sleep(2)
            self.start_server()

        threading.Thread(target=restart_worker, daemon=True).start()
        return True, "Сервер останавливается и будет перезапущен"

    def send_command(self, cmd_text):
        with self.lock:
            if self.process is None or self.process.poll() is not None:
                return False, "Сервер не запущен"
            try:
                cmd_to_send = cmd_text.strip()
                if cmd_to_send.startswith("/"):
                    cmd_to_send = cmd_to_send[1:]
                self.process.stdin.write(cmd_to_send + "\n")
                self.process.stdin.flush()
                self.logs.append(f"[{time.strftime('%H:%M:%S')}] [COMMAND] > {cmd_to_send}")
                return True, f"Команда '{cmd_to_send}' отправлена"
            except Exception as e:
                return False, f"Ошибка отправки команды: {e}"

    def get_status(self):
        with self.lock:
            is_running = self.process is not None and self.process.poll() is None
            if not is_running:
                curr_state = "offline"
            else:
                curr_state = self.state

            uptime = 0
            if is_running and self.start_time:
                uptime = int(time.time() - self.start_time)

            return {
                "state": curr_state,
                "is_running": is_running,
                "uptime_seconds": uptime,
                "server_dir": self.get_server_dir(),
                "launch_file": self.get_launch_file(),
                "full_path": self.get_full_script_path(),
                "script_exists": os.path.exists(self.get_full_script_path()),
                "timestamp": int(time.time())
            }


class RequestHandler(BaseHTTPRequestHandler):
    manager = None
    auth_token = None

    def _send_cors(self):
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type, Authorization, X-Auth-Token")

    def _send_json(self, status_code, data):
        self.send_response(status_code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self._send_cors()
        self.end_headers()
        self.wfile.write(json.dumps(data, ensure_ascii=False).encode("utf-8"))

    def do_OPTIONS(self):
        self.send_response(204)
        self._send_cors()
        self.end_headers()

    def _check_auth(self):
        # Проверяем токен из заголовка X-Auth-Token или Authorization: Bearer <token>
        token = self.headers.get("X-Auth-Token")
        if not token:
            auth = self.headers.get("Authorization", "")
            if auth.startswith("Bearer "):
                token = auth[7:].strip()
        
        # Если передан query parameter ?token=
        if not token and "?" in self.path:
            params = self.path.split("?", 1)[1]
            for p in params.split("&"):
                if p.startswith("token="):
                    token = p[6:]

        return token == self.auth_token

    def _read_json_body(self):
        try:
            content_len = int(self.headers.get('Content-Length', 0))
            if content_len > 0:
                raw_data = self.rfile.read(content_len).decode('utf-8')
                return json.loads(raw_data)
        except Exception:
            pass
        return {}

    def do_GET(self):
        clean_path = self.path.split("?")[0]

        if clean_path == "/api/ping":
            self._send_json(200, {"success": True, "name": "MineServer Agent", "version": VERSION})
            return

        if not self._check_auth():
            self._send_json(401, {"success": False, "error": "Неверный токен авторизации"})
            return

        if clean_path == "/api/status":
            status_data = self.manager.get_status()
            self._send_json(200, {"success": True, "data": status_data})
        elif clean_path == "/api/logs":
            self._send_json(200, {"success": True, "logs": list(self.manager.logs)})
        elif clean_path == "/api/settings":
            self._send_json(200, {
                "success": True,
                "server_dir": self.manager.get_server_dir(),
                "launch_file": self.manager.get_launch_file(),
                "full_path": self.manager.get_full_script_path(),
                "exists": os.path.exists(self.manager.get_full_script_path())
            })
        else:
            self._send_json(404, {"success": False, "error": "Маршрут не найден"})

    def do_POST(self):
        clean_path = self.path.split("?")[0]

        if not self._check_auth():
            self._send_json(401, {"success": False, "error": "Неверный токен авторизации"})
            return

        body = self._read_json_body()

        if clean_path == "/api/start":
            ok, msg = self.manager.start_server()
            self._send_json(200 if ok else 400, {"success": ok, "message": msg})
        elif clean_path == "/api/stop":
            force = body.get("force", False)
            ok, msg = self.manager.stop_server(force=force)
            self._send_json(200 if ok else 400, {"success": ok, "message": msg})
        elif clean_path == "/api/restart":
            ok, msg = self.manager.restart_server()
            self._send_json(200 if ok else 400, {"success": ok, "message": msg})
        elif clean_path == "/api/command":
            cmd = body.get("command", "")
            if not cmd:
                self._send_json(400, {"success": False, "error": "Команда не указана"})
                return
            ok, msg = self.manager.send_command(cmd)
            self._send_json(200 if ok else 400, {"success": ok, "message": msg})
        elif clean_path == "/api/settings":
            if "server_dir" in body:
                self.manager.config["server_dir"] = body["server_dir"]
            if "launch_file" in body:
                self.manager.config["launch_file"] = body["launch_file"]
            
            # Сохраняем в файл конфигурации
            try:
                save_config(self.manager.config)
                self._send_json(200, {
                    "success": True,
                    "message": "Настройки сохранены",
                    "server_dir": self.manager.get_server_dir(),
                    "launch_file": self.manager.get_launch_file(),
                    "full_path": self.manager.get_full_script_path(),
                    "exists": os.path.exists(self.manager.get_full_script_path())
                })
            except Exception as e:
                self._send_json(500, {"success": False, "error": f"Ошибка сохранения настроек: {e}"})
        else:
            self._send_json(404, {"success": False, "error": "Маршрут не найден"})

    def log_message(self, format, *args):
        # Отключаем дефолтный вывод каждого HTTP запроса в консоль, чтобы не спамить
        pass


def load_config():
    default_config = {
        "port": 8080,
        "token": secrets.token_hex(4).upper(),  # Простой 8-символьный токен
        "server_dir": r"C:\MinecraftServer",
        "launch_file": "start.bat"
    }
    if os.path.exists(CONFIG_FILE):
        try:
            with open(CONFIG_FILE, "r", encoding="utf-8") as f:
                data = json.load(f)
                default_config.update(data)
        except Exception as e:
            print(f"[!] Ошибка чтения {CONFIG_FILE}, создаём новый: {e}")
    save_config(default_config)
    return default_config

def save_config(cfg):
    with open(CONFIG_FILE, "w", encoding="utf-8") as f:
        json.dump(cfg, f, indent=4, ensure_ascii=False)


def find_network_ips():
    tailscale_ips = []
    local_ips = []
    try:
        hostname = socket.gethostname()
        for item in socket.getaddrinfo(hostname, None):
            ip = item[4][0]
            if ":" in ip:  # Пропускаем IPv6 для простоты
                continue
            if ip.startswith("127."):
                continue
            if ip.startswith("100."):  # Диапазон адресов Tailscale (CGNAT 100.64.0.0/10)
                if ip not in tailscale_ips:
                    tailscale_ips.append(ip)
            else:
                if ip not in local_ips:
                    local_ips.append(ip)
    except Exception:
        pass
    return tailscale_ips, local_ips


def main():
    print("=" * 60)
    print(f"        🎮 MineServer Remote Agent v{VERSION}        ")
    print("=" * 60)

    cfg = load_config()
    port = int(cfg.get("port", 8080))
    token = cfg.get("token", "123456")

    manager = ServerManager(cfg)
    RequestHandler.manager = manager
    RequestHandler.auth_token = token

    tailscale_ips, local_ips = find_network_ips()

    print("[+] Агент успешно запущен и ожидает подключений!")
    print("\n[Данные для подключения в приложении на телефоне]:")
    
    if tailscale_ips:
        for tip in tailscale_ips:
            print(f"  👉 IP для мобильного интернета (Tailscale): {tip}:{port}")
    else:
        print("  ⚠️  Tailscale IP не найден (убедитесь, что Tailscale запущен на ПК)")

    if local_ips:
        for lip in local_ips:
            print(f"  🏠 IP для домашнего Wi-Fi: {lip}:{port}")
    else:
        print(f"  🏠 Локальный порт: :{port}")

    print(f"\n  🔑 Секретный токен:  {token}")
    print(f"  📁 Папка сервера:    {manager.get_server_dir()}")
    print(f"  ⚡ Файл запуска:     {manager.get_launch_file()}")
    
    full_path = manager.get_full_script_path()
    if os.path.exists(full_path):
        print(f"  [✓] Файл запуска проверен: найден!")
    else:
        print(f"  [!] Внимание: файл '{full_path}' пока не найден.")
        print(f"      (Вы сможете указать правильную папку прямо с телефона!)")

    print("\n" + "=" * 60)
    print("  Окно можно свернуть. Сервер готов к управлению.")
    print("  Нажмите Ctrl+C для выхода.")
    print("=" * 60 + "\n")

    server_address = ('0.0.0.0', port)
    try:
        httpd = HTTPServer(server_address, RequestHandler)
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\n[!] Остановка агента...")
        manager.stop_server(force=True)
        sys.exit(0)
    except Exception as e:
        print(f"\n[X] Критическая ошибка сервера: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()
