#!/usr/bin/env python3
"""
MineServer Remote Agent v3.0 (ngrok Edition)
- Открывает сервер в отдельном видимом окне Windows
- Читает logs/latest.log в реальном времени
- Передаёт любые команды (op, tick, stop) в окно работающего сервера
- Поддерживает ngrok и локальную сеть
"""

import os
import sys
import json
import time
import socket
import secrets
import subprocess
import threading
from collections import deque
from http.server import HTTPServer, BaseHTTPRequestHandler

VERSION = "3.0.0"
CONFIG_FILE = "config.json"

class ServerManager:
    def __init__(self, config):
        self.config = config
        self.state = "offline"
        self.logs = deque(maxlen=300)
        self.lock = threading.Lock()
        self.start_time = None
        self.last_log_size = 0
        self.last_log_file = ""

        # Фоновый мониторинг процесса и логов
        self.monitor_thread = threading.Thread(target=self._monitor_loop, daemon=True)
        self.monitor_thread.start()

    def get_server_dir(self):
        return self.config.get("server_dir", "")

    def get_launch_file(self):
        return self.config.get("launch_file", "start.bat")

    def get_full_script_path(self):
        s_dir = self.get_server_dir()
        s_file = self.get_launch_file()
        if not s_dir:
            return s_file
        return os.path.join(s_dir, s_file)

    def is_java_running(self):
        """Проверяет, запущен ли процесс java.exe на компьютере"""
        try:
            if sys.platform.startswith("win"):
                out = subprocess.check_output('tasklist /FI "IMAGENAME eq java.exe" /NH', shell=True, text=True)
                return "java.exe" in out.lower()
            else:
                out = subprocess.check_output('pgrep -f java || true', shell=True, text=True)
                return len(out.strip()) > 0
        except Exception:
            pass
        return False

    def _monitor_loop(self):
        """Постоянно читает logs/latest.log и обновляет состояние сервера"""
        while True:
            time.sleep(1.0)
            is_running = self.is_java_running()

            with self.lock:
                if is_running:
                    if self.state != "stopping":
                        self.state = "online"
                    if not self.start_time:
                        self.start_time = time.time()
                else:
                    self.state = "offline"
                    self.start_time = None

            s_dir = self.get_server_dir()
            if not s_dir or not os.path.exists(s_dir):
                continue

            log_file = os.path.join(s_dir, "logs", "latest.log")
            if not os.path.exists(log_file):
                continue

            if log_file != self.last_log_file:
                self.last_log_file = log_file
                try:
                    self.last_log_size = max(0, os.path.getsize(log_file) - 5000)
                except Exception:
                    self.last_log_size = 0

            try:
                curr_size = os.path.getsize(log_file)
                if curr_size > self.last_log_size:
                    with open(log_file, "r", encoding="utf-8", errors="replace") as f:
                        f.seek(self.last_log_size)
                        new_lines = f.readlines()
                        self.last_log_size = f.tell()

                    if new_lines:
                        with self.lock:
                            for line in new_lines:
                                cl = line.rstrip('\r\n')
                                if cl and cl not in self.logs:
                                    self.logs.append(cl)
                elif curr_size < self.last_log_size:
                    self.last_log_size = 0
            except Exception:
                pass

    def start_server(self):
        with self.lock:
            if self.is_java_running():
                self.state = "online"
                return False, "Сервер Майнкрафта уже запущен на ПК!"

            script_path = self.get_full_script_path()
            server_dir = self.get_server_dir()

            if not os.path.exists(script_path):
                return False, f"Файл запуска не найден: {script_path}"

            self.state = "starting"
            self.logs.clear()
            msg = f"[{time.strftime('%H:%M:%S')}] [AGENT] Запуск сервера в отдельном окне: {script_path}"
            self.logs.append(msg)
            print(msg)

            try:
                if sys.platform.startswith("win"):
                    # Запуск в отдельном видимом окне с заголовком "Minecraft Server"
                    cmd = f'start "Minecraft Server" /D "{server_dir}" "{script_path}"'
                    subprocess.Popen(cmd, shell=True)
                else:
                    cmd = ["bash", script_path] if script_path.endswith(".sh") else [script_path]
                    subprocess.Popen(cmd, cwd=server_dir)

                self.start_time = time.time()
                return True, "Сервер открыт в отдельном окне на ПК"
            except Exception as e:
                self.state = "offline"
                self.logs.append(f"[{time.strftime('%H:%M:%S')}] [AGENT ERROR] {e}")
                return False, f"Ошибка запуска: {e}"

    def stop_server(self, force=False):
        if not self.is_java_running():
            with self.lock:
                self.state = "offline"
            return False, "Сервер не запущен"

        if force:
            try:
                subprocess.run('taskkill /F /IM java.exe /T', shell=True)
                with self.lock:
                    self.state = "offline"
                return True, "Процесс java.exe принудительно завершён"
            except Exception as e:
                return False, f"Ошибка принудительного завершения: {e}"

        with self.lock:
            self.state = "stopping"
        
        # Отправляем команду stop в окно сервера
        return self.send_command("stop")

    def restart_server(self):
        self.stop_server()
        def restart_worker():
            for _ in range(40):
                if not self.is_java_running():
                    break
                time.sleep(1)
            time.sleep(2)
            self.start_server()

        threading.Thread(target=restart_worker, daemon=True).start()
        return True, "Сервер останавливается и будет перезапущен"

    def send_command(self, cmd_text):
        cmd_to_send = cmd_text.strip()
        if cmd_to_send.startswith("/"):
            cmd_to_send = cmd_to_send[1:]

        if not self.is_java_running():
            return False, "Сервер Майнкрафта не запущен на ПК"

        if sys.platform.startswith("win"):
            try:
                # Имитация ввода команды в окно консоли Minecraft
                ps_script = (
                    f'$ws = New-Object -ComObject wscript.shell; '
                    f'if ($ws.AppActivate("Minecraft Server") -or $ws.AppActivate("Minecraft") -or $ws.AppActivate("cmd") -or $ws.AppActivate("Select")) {{ '
                    f'Start-Sleep -Milliseconds 120; '
                    f'$ws.SendKeys("{cmd_to_send}{{ENTER}}"); '
                    f'}}'
                )
                subprocess.run(["powershell", "-NoProfile", "-Command", ps_script], timeout=4)
                with self.lock:
                    self.logs.append(f"[{time.strftime('%H:%M:%S')}] [COMMAND] > {cmd_to_send}")
                print(f"[CMD INJECTED] > {cmd_to_send}")
                return True, f"Команда '{cmd_to_send}' отправлена в окно сервера"
            except Exception as e:
                return False, f"Ошибка отправки команды: {e}"

        return False, "Команды поддерживаются в Windows"

    def get_status(self):
        with self.lock:
            running = self.is_java_running()
            curr_state = self.state if (running and self.state in ["starting", "stopping"]) else ("online" if running else "offline")

            uptime = 0
            if running and self.start_time:
                uptime = int(time.time() - self.start_time)

            return {
                "state": curr_state,
                "is_running": running,
                "uptime_seconds": uptime,
                "server_dir": self.get_server_dir(),
                "launch_file": self.get_launch_file(),
                "full_path": self.get_full_script_path(),
                "script_exists": os.path.exists(self.get_full_script_path()),
                "timestamp": int(time.time())
            }


class RequestHandler(BaseHTTPRequestHandler):
    manager = None
    auth_token = None

    def _send_cors(self):
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type, Authorization, X-Auth-Token, ngrok-skip-browser-warning")

    def _send_json(self, status_code, data):
        self.send_response(status_code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self._send_cors()
        self.end_headers()
        self.wfile.write(json.dumps(data, ensure_ascii=False).encode("utf-8"))

    def do_OPTIONS(self):
        self.send_response(204)
        self._send_cors()
        self.end_headers()

    def _check_auth(self):
        token = self.headers.get("X-Auth-Token")
        if not token:
            auth = self.headers.get("Authorization", "")
            if auth.startswith("Bearer "):
                token = auth[7:].strip()
        
        if not token and "?" in self.path:
            params = self.path.split("?", 1)[1]
            for p in params.split("&"):
                if p.startswith("token="):
                    token = p[6:]

        return token == self.auth_token

    def _read_json_body(self):
        try:
            content_len = int(self.headers.get('Content-Length', 0))
            if content_len > 0:
                raw_data = self.rfile.read(content_len).decode('utf-8')
                return json.loads(raw_data)
        except Exception:
            pass
        return {}

    def do_GET(self):
        clean_path = self.path.split("?")[0]

        if clean_path == "/api/ping":
            self._send_json(200, {"success": True, "name": "MineServer Agent (ngrok Edition)", "version": VERSION})
            return

        if not self._check_auth():
            self._send_json(401, {"success": False, "error": "Неверный токен авторизации"})
            return

        if clean_path == "/api/status":
            self._send_json(200, {"success": True, "data": self.manager.get_status()})
        elif clean_path == "/api/logs":
            self._send_json(200, {"success": True, "logs": list(self.manager.logs)})
        elif clean_path == "/api/settings":
            self._send_json(200, {
                "success": True,
                "server_dir": self.manager.get_server_dir(),
                "launch_file": self.manager.get_launch_file(),
                "full_path": self.manager.get_full_script_path(),
                "exists": os.path.exists(self.manager.get_full_script_path())
            })
        else:
            self._send_json(404, {"success": False, "error": "Маршрут не найден"})

    def do_POST(self):
        clean_path = self.path.split("?")[0]

        if not self._check_auth():
            self._send_json(401, {"success": False, "error": "Неверный токен авторизации"})
            return

        body = self._read_json_body()

        if clean_path == "/api/start":
            ok, msg = self.manager.start_server()
            self._send_json(200 if ok else 400, {"success": ok, "message": msg})
        elif clean_path == "/api/stop":
            force = body.get("force", False)
            ok, msg = self.manager.stop_server(force=force)
            self._send_json(200 if ok else 400, {"success": ok, "message": msg})
        elif clean_path == "/api/restart":
            ok, msg = self.manager.restart_server()
            self._send_json(200 if ok else 400, {"success": ok, "message": msg})
        elif clean_path == "/api/command":
            cmd = body.get("command", "")
            if not cmd:
                self._send_json(400, {"success": False, "error": "Команда не указана"})
                return
            ok, msg = self.manager.send_command(cmd)
            self._send_json(200 if ok else 400, {"success": ok, "message": msg})
        elif clean_path == "/api/settings":
            if "server_dir" in body:
                self.manager.config["server_dir"] = body["server_dir"]
            if "launch_file" in body:
                self.manager.config["launch_file"] = body["launch_file"]
            try:
                save_config(self.manager.config)
                self._send_json(200, {
                    "success": True,
                    "message": "Настройки сохранены",
                    "server_dir": self.manager.get_server_dir(),
                    "launch_file": self.manager.get_launch_file(),
                    "full_path": self.manager.get_full_script_path(),
                    "exists": os.path.exists(self.manager.get_full_script_path())
                })
            except Exception as e:
                self._send_json(500, {"success": False, "error": f"Ошибка: {e}"})
        else:
            self._send_json(404, {"success": False, "error": "Маршрут не найден"})

    def log_message(self, format, *args):
        pass


def load_config():
    default_config = {
        "port": 8080,
        "token": secrets.token_hex(4).upper(),
        "server_dir": r"C:\MinecraftServer",
        "launch_file": "start.bat"
    }
    if os.path.exists(CONFIG_FILE):
        try:
            with open(CONFIG_FILE, "r", encoding="utf-8") as f:
                data = json.load(f)
                default_config.update(data)
        except Exception:
            pass
    save_config(default_config)
    return default_config

def save_config(cfg):
    with open(CONFIG_FILE, "w", encoding="utf-8") as f:
        json.dump(cfg, f, indent=4, ensure_ascii=False)


def main():
    print("=" * 66)
    print(f"       🎮 MineServer Remote Agent v{VERSION} (ngrok Edition)       ")
    print("=" * 66)

    cfg = load_config()
    port = int(cfg.get("port", 8080))
    token = cfg.get("token", "123456")

    manager = ServerManager(cfg)
    RequestHandler.manager = manager
    RequestHandler.auth_token = token

    print("[+] Агент успешно запущен и слушает порт :8080")
    print(f"  🔑 Токен доступа для приложения:  {token}")
    print(f"  📁 Папка сервера:                   {manager.get_server_dir()}")
    print(f"  ⚡ Файл запуска:                    {manager.get_launch_file()}")

    if manager.is_java_running():
        print("\n  🟢 СЕРВЕР МАЙНКРАФТА УЖЕ РАБОТАЕТ В ОТДЕЛЬНОМ ОКНЕ!")
        print("     Агент подключился: логи и команды активны.")
    else:
        print("\n  ⚪ Сервер сейчас выключен (нажмите 'ЗАПУСК' в приложении).")
        print("     При запуске сервер откроется в своём отдельном черном окне.")

    print("\n" + "=" * 66)
    print("  🌐 ПОДКЛЮЧЕНИЕ ЧЕРЕЗ NGROK:")
    print("  1. Запустите start_tunnel.bat (ngrok).")
    print("  2. В приложении введите ваш постоянный адрес ngrok и токен.")
    print("=" * 66 + "\n")

    server_address = ('0.0.0.0', port)
    try:
        httpd = HTTPServer(server_address, RequestHandler)
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\n[!] Завершение работы...")
        sys.exit(0)
    except Exception as e:
        print(f"\n[X] Ошибка: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()
