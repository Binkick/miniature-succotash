#!/usr/bin/env python3
"""
MineServer Remote Agent v2.0 (Playit.gg Edition)
Полноценный агент для ПК:
- Интеграция с Playit.gg (постоянный адрес без VPN на телефоне)
- Поддержка уже запущенного сервера (чтение latest.log + ввод команд)
- Управление start.bat, /stop и перезагрузка
"""

import os
import sys
import json
import time
import socket
import secrets
import subprocess
import threading
from collections import deque
from http.server import HTTPServer, BaseHTTPRequestHandler

VERSION = "2.0.0"
CONFIG_FILE = "config.json"

class ServerManager:
    def __init__(self, config):
        self.config = config
        self.process = None
        self.state = "offline"
        self.logs = deque(maxlen=250)
        self.lock = threading.Lock()
        self.start_time = None
        self.reader_thread = None

        # Фоновый поток для отслеживания logs/latest.log
        self.tail_thread = threading.Thread(target=self._tail_latest_log_loop, daemon=True)
        self.tail_thread.start()

    def get_server_dir(self):
        return self.config.get("server_dir", "")

    def get_launch_file(self):
        return self.config.get("launch_file", "start.bat")

    def get_full_script_path(self):
        s_dir = self.get_server_dir()
        s_file = self.get_launch_file()
        if not s_dir:
            return s_file
        return os.path.join(s_dir, s_file)

    def is_java_running(self):
        try:
            if sys.platform.startswith("win"):
                out = subprocess.check_output('tasklist /FI "IMAGENAME eq java.exe" /NH', shell=True, text=True)
                return "java.exe" in out.lower()
        except Exception:
            pass
        return False

    def _tail_latest_log_loop(self):
        """Читает latest.log для уже запущенных серверов"""
        last_pos = 0
        last_path = ""

        while True:
            time.sleep(1.5)
            s_dir = self.get_server_dir()
            if not s_dir or not os.path.exists(s_dir):
                continue

            log_file = os.path.join(s_dir, "logs", "latest.log")
            if not os.path.exists(log_file):
                continue

            if log_file != last_path:
                last_path = log_file
                try:
                    last_pos = max(0, os.path.getsize(log_file) - 4000)
                except Exception:
                    last_pos = 0

            with self.lock:
                if self.process is None:
                    if self.is_java_running():
                        self.state = "online"
                    else:
                        self.state = "offline"

            try:
                curr_size = os.path.getsize(log_file)
                if curr_size > last_pos:
                    with open(log_file, "r", encoding="utf-8", errors="replace") as f:
                        f.seek(last_pos)
                        new_lines = f.readlines()
                        last_pos = f.tell()

                    if new_lines:
                        with self.lock:
                            for line in new_lines:
                                cl = line.rstrip('\r\n')
                                if cl and cl not in self.logs:
                                    self.logs.append(cl)
                                    if self.process is None:
                                        print(f"[SRV] {cl}")
                elif curr_size < last_pos:
                    last_pos = 0
            except Exception:
                pass

    def start_server(self):
        with self.lock:
            if self.process is not None and self.process.poll() is None:
                return False, "Сервер уже запущен агентом"

            if self.is_java_running():
                self.state = "online"
                return False, "Сервер Майнкрафта уже запущен на ПК!"

            script_path = self.get_full_script_path()
            server_dir = self.get_server_dir()

            if not os.path.exists(script_path):
                return False, f"Файл запуска не найден: {script_path}"

            self.state = "starting"
            self.logs.clear()
            msg = f"[{time.strftime('%H:%M:%S')}] [AGENT] Запуск сервера: {script_path}"
            self.logs.append(msg)
            print(msg)

            try:
                if sys.platform.startswith("win"):
                    cmd = f'"{script_path}"'
                else:
                    cmd = ["bash", script_path] if script_path.endswith(".sh") else [script_path]

                self.process = subprocess.Popen(
                    cmd,
                    cwd=server_dir if server_dir and os.path.exists(server_dir) else None,
                    stdin=subprocess.PIPE,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.STDOUT,
                    text=True,
                    bufsize=1,
                    universal_newlines=True,
                    shell=sys.platform.startswith("win")
                )
                self.start_time = time.time()
                
                self.reader_thread = threading.Thread(target=self._read_output, daemon=True)
                self.reader_thread.start()
                return True, "Сервер успешно запускается"
            except Exception as e:
                self.state = "offline"
                self.logs.append(f"[{time.strftime('%H:%M:%S')}] [AGENT ERROR] Ошибка: {e}")
                return False, f"Ошибка запуска: {str(e)}"

    def _read_output(self):
        proc = self.process
        if not proc or not proc.stdout:
            return

        for line in iter(proc.stdout.readline, ''):
            cleaned = line.rstrip('\r\n')
            if cleaned:
                self.logs.append(cleaned)
                print(f"[SRV] {cleaned}")
                lowered = cleaned.lower()
                if "done (" in lowered or "for help, type" in lowered:
                    self.state = "online"

        proc.stdout.close()
        proc.wait()
        with self.lock:
            self.state = "offline"
            self.process = None
            self.start_time = None
            msg = f"[{time.strftime('%H:%M:%S')}] [AGENT] Процесс сервера завершён."
            self.logs.append(msg)
            print(msg)

    def stop_server(self, force=False):
        with self.lock:
            if self.process is not None and self.process.poll() is None:
                if force:
                    self.process.kill()
                    self.state = "offline"
                    self.process = None
                    return True, "Сервер принудительно остановлен"

                self.state = "stopping"
                try:
                    if self.process.stdin:
                        self.process.stdin.write("stop\n")
                        self.process.stdin.flush()
                    return True, "Команда stop отправлена"
                except Exception as e:
                    return False, f"Ошибка отправки stop: {e}"

            if self.is_java_running():
                return self.send_command("stop")

            self.state = "offline"
            return False, "Сервер не запущен"

    def restart_server(self):
        stopped, msg = self.stop_server()
        def restart_worker():
            for _ in range(40):
                if not self.is_java_running() and self.process is None:
                    break
                time.sleep(1)
            time.sleep(2)
            self.start_server()

        threading.Thread(target=restart_worker, daemon=True).start()
        return True, "Сервер перезапускается"

    def send_command(self, cmd_text):
        cmd_to_send = cmd_text.strip()
        if cmd_to_send.startswith("/"):
            cmd_to_send = cmd_to_send[1:]

        with self.lock:
            if self.process is not None and self.process.poll() is None:
                try:
                    self.process.stdin.write(cmd_to_send + "\n")
                    self.process.stdin.flush()
                    self.logs.append(f"[{time.strftime('%H:%M:%S')}] [COMMAND] > {cmd_to_send}")
                    print(f"[CMD] > {cmd_to_send}")
                    return True, f"Команда '{cmd_to_send}' отправлена в процесс"
                except Exception as e:
                    return False, f"Ошибка: {e}"

            if self.is_java_running() and sys.platform.startswith("win"):
                try:
                    ps_script = (
                        f'$ws = New-Object -ComObject wscript.shell; '
                        f'if ($ws.AppActivate("Minecraft") -or $ws.AppActivate("server") -or $ws.AppActivate("cmd") -or $ws.AppActivate("Select")) {{ '
                        f'Start-Sleep -Milliseconds 150; '
                        f'$ws.SendKeys("{cmd_to_send}{{ENTER}}"); '
                        f'}}'
                    )
                    subprocess.run(["powershell", "-NoProfile", "-Command", ps_script], timeout=4)
                    self.logs.append(f"[{time.strftime('%H:%M:%S')}] [COMMAND INJECTED] > {cmd_to_send}")
                    print(f"[CMD INJECTED] > {cmd_to_send}")
                    return True, f"Команда '{cmd_to_send}' передана в окно сервера!"
                except Exception as e:
                    return False, f"Ошибка передачи в окно: {e}"

            return False, "Сервер Майнкрафта не обнаружен на ПК"

    def get_status(self):
        with self.lock:
            is_proc_running = self.process is not None and self.process.poll() is None
            is_ext_running = self.is_java_running()
            running = is_proc_running or is_ext_running

            if running:
                curr_state = self.state if self.state in ["starting", "stopping"] else "online"
            else:
                curr_state = "offline"

            uptime = 0
            if is_proc_running and self.start_time:
                uptime = int(time.time() - self.start_time)

            return {
                "state": curr_state,
                "is_running": running,
                "uptime_seconds": uptime,
                "server_dir": self.get_server_dir(),
                "launch_file": self.get_launch_file(),
                "full_path": self.get_full_script_path(),
                "script_exists": os.path.exists(self.get_full_script_path()),
                "timestamp": int(time.time())
            }


class RequestHandler(BaseHTTPRequestHandler):
    manager = None
    auth_token = None

    def _send_cors(self):
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type, Authorization, X-Auth-Token")

    def _send_json(self, status_code, data):
        self.send_response(status_code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self._send_cors()
        self.end_headers()
        self.wfile.write(json.dumps(data, ensure_ascii=False).encode("utf-8"))

    def do_OPTIONS(self):
        self.send_response(204)
        self._send_cors()
        self.end_headers()

    def _check_auth(self):
        token = self.headers.get("X-Auth-Token")
        if not token:
            auth = self.headers.get("Authorization", "")
            if auth.startswith("Bearer "):
                token = auth[7:].strip()
        
        if not token and "?" in self.path:
            params = self.path.split("?", 1)[1]
            for p in params.split("&"):
                if p.startswith("token="):
                    token = p[6:]

        return token == self.auth_token

    def _read_json_body(self):
        try:
            content_len = int(self.headers.get('Content-Length', 0))
            if content_len > 0:
                raw_data = self.rfile.read(content_len).decode('utf-8')
                return json.loads(raw_data)
        except Exception:
            pass
        return {}

    def do_GET(self):
        clean_path = self.path.split("?")[0]

        if clean_path == "/api/ping":
            self._send_json(200, {"success": True, "name": "MineServer Agent (Playit.gg)", "version": VERSION})
            return

        if not self._check_auth():
            self._send_json(401, {"success": False, "error": "Неверный токен авторизации"})
            return

        if clean_path == "/api/status":
            self._send_json(200, {"success": True, "data": self.manager.get_status()})
        elif clean_path == "/api/logs":
            self._send_json(200, {"success": True, "logs": list(self.manager.logs)})
        elif clean_path == "/api/settings":
            self._send_json(200, {
                "success": True,
                "server_dir": self.manager.get_server_dir(),
                "launch_file": self.manager.get_launch_file(),
                "full_path": self.manager.get_full_script_path(),
                "exists": os.path.exists(self.manager.get_full_script_path())
            })
        else:
            self._send_json(404, {"success": False, "error": "Маршрут не найден"})

    def do_POST(self):
        clean_path = self.path.split("?")[0]

        if not self._check_auth():
            self._send_json(401, {"success": False, "error": "Неверный токен авторизации"})
            return

        body = self._read_json_body()

        if clean_path == "/api/start":
            ok, msg = self.manager.start_server()
            self._send_json(200 if ok else 400, {"success": ok, "message": msg})
        elif clean_path == "/api/stop":
            force = body.get("force", False)
            ok, msg = self.manager.stop_server(force=force)
            self._send_json(200 if ok else 400, {"success": ok, "message": msg})
        elif clean_path == "/api/restart":
            ok, msg = self.manager.restart_server()
            self._send_json(200 if ok else 400, {"success": ok, "message": msg})
        elif clean_path == "/api/command":
            cmd = body.get("command", "")
            if not cmd:
                self._send_json(400, {"success": False, "error": "Команда не указана"})
                return
            ok, msg = self.manager.send_command(cmd)
            self._send_json(200 if ok else 400, {"success": ok, "message": msg})
        elif clean_path == "/api/settings":
            if "server_dir" in body:
                self.manager.config["server_dir"] = body["server_dir"]
            if "launch_file" in body:
                self.manager.config["launch_file"] = body["launch_file"]
            try:
                save_config(self.manager.config)
                self._send_json(200, {
                    "success": True,
                    "message": "Настройки сохранены",
                    "server_dir": self.manager.get_server_dir(),
                    "launch_file": self.manager.get_launch_file(),
                    "full_path": self.manager.get_full_script_path(),
                    "exists": os.path.exists(self.manager.get_full_script_path())
                })
            except Exception as e:
                self._send_json(500, {"success": False, "error": f"Ошибка сохранения: {e}"})
        else:
            self._send_json(404, {"success": False, "error": "Маршрут не найден"})

    def log_message(self, format, *args):
        pass


def load_config():
    default_config = {
        "port": 8080,
        "token": secrets.token_hex(4).upper(),
        "server_dir": r"C:\MinecraftServer",
        "launch_file": "start.bat"
    }
    if os.path.exists(CONFIG_FILE):
        try:
            with open(CONFIG_FILE, "r", encoding="utf-8") as f:
                data = json.load(f)
                default_config.update(data)
        except Exception:
            pass
    save_config(default_config)
    return default_config

def save_config(cfg):
    with open(CONFIG_FILE, "w", encoding="utf-8") as f:
        json.dump(cfg, f, indent=4, ensure_ascii=False)


def main():
    print("=" * 66)
    print(f"       🎮 MineServer Remote Agent v{VERSION} (Playit.gg Edition)       ")
    print("=" * 66)

    cfg = load_config()
    port = int(cfg.get("port", 8080))
    token = cfg.get("token", "123456")

    manager = ServerManager(cfg)
    RequestHandler.manager = manager
    RequestHandler.auth_token = token

    print("[+] Агент успешно запущен и слушает порт :8080")
    print(f"  🔑 Секретный токен для приложения:  {token}")
    print(f"  📁 Папка сервера:                   {manager.get_server_dir()}")
    print(f"  ⚡ Файл запуска:                    {manager.get_launch_file()}")

    if manager.is_java_running():
        print("\n  🟢 ОБНАРУЖЕН УЖЕ ЗАПУЩЕННЫЙ СЕРВЕР МАЙНКРАФТА!")
        print("     Агент автоматически подключился: логи и команды активны.")

    print("\n" + "=" * 66)
    print("  🌐 ИНСТРУКЦИЯ ПО ПОДКЛЮЧЕНИЮ ЧЕРЕЗ PLAYIT.GG:")
    print("  1. Запустите Playit.gg на этом компьютере.")
    print("  2. В Playit нажмите 'Add Tunnel', выберите HTTP, порт: 8080.")
    print("  3. Скопируйте постоянный адрес (например: abc.at.ply.gg:12345).")
    print(f"  4. В приложении на телефоне укажите этот адрес и токен: {token}")
    print("=" * 66 + "\n")

    server_address = ('0.0.0.0', port)
    try:
        httpd = HTTPServer(server_address, RequestHandler)
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\n[!] Завершение работы...")
        sys.exit(0)
    except Exception as e:
        print(f"\n[X] Ошибка: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()
