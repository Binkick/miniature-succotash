package com.servercontrol.app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
