import 'package:flutter/material.dart';

class InstructionsScreen extends StatelessWidget {
  const InstructionsScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Инструкция (Playit.gg)'),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16.0),
        children: [
          _buildStepCard(
            step: '1',
            icon: Icons.computer,
            title: 'Установите Playit на ПК (1 минута)',
            description:
                'Playit даёт постоянный адрес в интернете без смены ссылок и без VPN на телефоне.\n\n'
                '• Скачайте программу с официального сайта playit.gg на компьютер с сервером.\n'
                '• Запустите её — откроется страница в браузере для быстрой привязки.',
          ),
          const SizedBox(height: 12),
          _buildStepCard(
            step: '2',
            icon: Icons.alt_route,
            title: 'Создайте туннель в Playit',
            description:
                'На сайте Playit нажмите «Add Tunnel»:\n\n'
                '• Tunnel Type: выберите «HTTP» (или TCP/Custom)\n'
                '• Local Port: укажите 8080\n'
                '• Playit выдаст постоянный статический адрес (например: abc-xyz.at.ply.gg:15432). Этот адрес никогда не меняется!',
          ),
          const SizedBox(height: 12),
          _buildStepCard(
            step: '3',
            icon: Icons.phonelink_setup,
            title: 'Подключите телефон',
            description:
                '1. Запустите ServerAgent.exe на компьютере (он покажет секретный токен).\n'
                '2. В этом приложении нажмите «+ Добавить сервер»:\n'
                '   • Вставьте постоянный адрес из Playit (например: abc.at.ply.gg:15432)\n'
                '   • Введите токен из окна ServerAgent\n'
                '3. Нажмите «Сохранить». Ваш обычный VPN на телефоне остаётся включённым и ни с чем не конфликтует!',
          ),
          const SizedBox(height: 12),
          _buildStepCard(
            step: '👥',
            icon: Icons.people,
            title: 'Как поделиться с другом',
            description:
                'Чтобы друг тоже мог управлять сервером:\n\n'
                '1. Скиньте другу это приложение (ServerControl.apk).\n'
                '2. Дайте другу ваш адрес Playit и токен доступа.\n'
                '3. Друг нажимает «+ Добавить сервер» у себя в приложении — и у него тоже появляется доступ!',
          ),
          const SizedBox(height: 20),
          Card(
            color: Colors.blueGrey.shade900,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
            child: const Padding(
              padding: EdgeInsets.all(16.0),
              child: Row(
                children: [
                  Icon(Icons.check_circle_outline, color: Colors.greenAccent),
                  SizedBox(width: 12),
                  Expanded(
                    child: Text(
                      'Постоянный адрес Playit закрепляется навсегда. Даже если перезагрузить ПК или роутер, адрес останется прежним.',
                      style: TextStyle(fontSize: 13, color: Colors.white70),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildStepCard({
    required String step,
    required IconData icon,
    required String title,
    required String description,
  }) {
    return Card(
      elevation: 2,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                CircleAvatar(
                  radius: 16,
                  backgroundColor: Colors.greenAccent.shade700,
                  child: Text(
                    step,
                    style: const TextStyle(
                      color: Colors.black,
                      fontWeight: FontWeight.bold,
                      fontSize: 14,
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                Icon(icon, color: Colors.greenAccent),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    title,
                    style: const TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ],
            ),
            const Divider(height: 20),
            Text(
              description,
              style: const TextStyle(
                fontSize: 14,
                height: 1.4,
                color: Colors.white70,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
