import 'package:flutter/material.dart';

class InstructionsScreen extends StatelessWidget {
  const InstructionsScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Инструкция по подключению'),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16.0),
        children: [
          _buildStepCard(
            step: '1',
            icon: Icons.vpn_lock,
            title: 'Установите Tailscale (1 минута)',
            description:
                'Tailscale объединяет телефон и компьютер в защищённую сеть без белого IP и настроек роутера.\n\n'
                '• На ПК: скачайте и установите Tailscale с официального сайта.\n'
                '• На телефоне: установите Tailscale из Google Play.\n'
                '• Войдите в один и тот же Google/Microsoft аккаунт на обоих устройствах.',
          ),
          const SizedBox(height: 12),
          _buildStepCard(
            step: '2',
            icon: Icons.computer,
            title: 'Запустите ServerAgent.exe на ПК',
            description:
                'Запустите файл ServerAgent.exe на компьютере, где лежит сервер Майнкрафта.\n\n'
                'В появившемся окне отобразится:\n'
                '• IP для мобильного интернета (вида 100.x.y.z:8080)\n'
                '• Секретный токен (например: A1B2C3D4)',
          ),
          const SizedBox(height: 12),
          _buildStepCard(
            step: '3',
            icon: Icons.phonelink_setup,
            title: 'Подключите телефон',
            description:
                'В этом приложении нажмите кнопку «+ Добавить сервер»:\n'
                '1. Введите любое понятное название (например, «Мой ПК»).\n'
                '2. Введите IP-адрес с портом из окна на ПК.\n'
                '3. Введите токен и нажмите «Сохранить».',
          ),
          const SizedBox(height: 12),
          _buildStepCard(
            step: '👥',
            icon: Icons.people,
            title: 'Как поделиться с другом',
            description:
                'Чтобы друг мог управлять вашим сервером (или вы его):\n\n'
                '1. Скиньте другу это приложение (ServerControl.apk).\n'
                '2. В приложении Tailscale нажмите «Share machine» (или войдите в один аккаунт) — так друг сможет пинговать ваш IP.\n'
                '3. Друг открывает приложение, нажимает «+ Добавить сервер», вводит ваш IP и ваш токен.\n'
                '4. Теперь и у вас, и у друга есть доступ! Вверху приложения можно в один клик переключаться между серверами.',
          ),
          const SizedBox(height: 20),
          Card(
            color: Colors.blueGrey.shade900,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
            child: const Padding(
              padding: EdgeInsets.all(16.0),
              child: Row(
                children: [
                  Icon(Icons.info_outline, color: Colors.cyanAccent),
                  SizedBox(width: 12),
                  Expanded(
                    child: Text(
                      'Все настройки сохраняются автоматически. На компьютере запускать сам сервер вручную не нужно — программа сделает это за вас!',
                      style: TextStyle(fontSize: 13, color: Colors.white70),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildStepCard({
    required String step,
    required IconData icon,
    required String title,
    required String description,
  }) {
    return Card(
      elevation: 2,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                CircleAvatar(
                  radius: 16,
                  backgroundColor: Colors.greenAccent.shade700,
                  child: Text(
                    step,
                    style: const TextStyle(
                      color: Colors.black,
                      fontWeight: FontWeight.bold,
                      fontSize: 14,
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                Icon(icon, color: Colors.greenAccent),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    title,
                    style: const TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ],
            ),
            const Divider(height: 20),
            Text(
              description,
              style: const TextStyle(
                fontSize: 14,
                height: 1.4,
                color: Colors.white70,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
