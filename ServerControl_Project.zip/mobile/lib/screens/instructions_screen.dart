import 'package:flutter/material.dart';

class InstructionsScreen extends StatelessWidget {
  const InstructionsScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Инструкция (ngrok)'),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16.0),
        children: [
          _buildStepCard(
            step: '1',
            icon: Icons.computer,
            title: 'Запуск на компьютере (хост)',
            description:
                '1. Запустите ngrok (файл start.bat) — в окне загорится зелёный статус «online».\n'
                '2. Запустите ServerAgent.exe — появится токен доступа.\n'
                '3. Сам сервер Майнкрафта можно запустить заранее руками, либо нажать «ЗАПУСК» в приложении на телефоне (он откроется в своём черном окне).',
          ),
          const SizedBox(height: 12),
          _buildStepCard(
            step: '2',
            icon: Icons.phonelink_setup,
            title: 'Подключение с телефона',
            description:
                'В этом приложении нажмите «+ Добавить сервер»:\n'
                '• Адрес: вставьте постоянный адрес ngrok (например: https://eradicate-book-activist.ngrok-free.dev)\n'
                '• Токен: перепишите 8-значный код из окна ServerAgent\n\n'
                'Нажмите «Сохранить». Связь работает с любого мобильного интернета и через любой VPN!',
          ),
          const SizedBox(height: 12),
          _buildStepCard(
            step: '👥',
            icon: Icons.share,
            title: 'Как поделиться с другом',
            description:
                '1. Отправьте другу файл ServerControl.apk через Telegram (он просто устанавливает его на телефон).\n'
                '2. Скиньте другу ваш постоянный адрес ngrok и токен доступа.\n'
                '3. Друг открывает приложение, нажимает «+ Добавить сервер», вводит эти данные и сразу получает доступ к серверу!',
          ),
          const SizedBox(height: 12),
          _buildStepCard(
            step: '🎮',
            icon: Icons.terminal,
            title: 'Команды и управление',
            description:
                '• Сервер работает в отдельном окне на ПК.\n'
                '• Вкладка «Консоль» на телефоне показывает живой чат и события из logs/latest.log.\n'
                '• Любые команды (op, tick stop, stop) передаются прямо в работающее окно игры.',
          ),
          const SizedBox(height: 20),
          Card(
            color: Colors.blueGrey.shade900,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
            child: const Padding(
              padding: EdgeInsets.all(16.0),
              child: Row(
                children: [
                  Icon(Icons.verified, color: Colors.greenAccent),
                  SizedBox(width: 12),
                  Expanded(
                    child: Text(
                      'Постоянный адрес ngrok привязан к вашему аккаунту и никогда не сменится. Перенастраивать телефон больше не нужно.',
                      style: TextStyle(fontSize: 13, color: Colors.white70),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildStepCard({
    required String step,
    required IconData icon,
    required String title,
    required String description,
  }) {
    return Card(
      elevation: 2,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                CircleAvatar(
                  radius: 16,
                  backgroundColor: Colors.greenAccent.shade700,
                  child: Text(
                    step,
                    style: const TextStyle(
                      color: Colors.black,
                      fontWeight: FontWeight.bold,
                      fontSize: 14,
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                Icon(icon, color: Colors.greenAccent),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    title,
                    style: const TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ],
            ),
            const Divider(height: 20),
            Text(
              description,
              style: const TextStyle(
                fontSize: 14,
                height: 1.4,
                color: Colors.white70,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
