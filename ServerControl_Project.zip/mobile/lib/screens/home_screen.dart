import 'dart:async';
import 'package:flutter/material.dart';
import '../models/server_host.dart';
import '../services/api_service.dart';
import 'console_screen.dart';
import 'settings_screen.dart';
import 'instructions_screen.dart';

class HomeScreen extends StatefulWidget {
  final List<ServerHost> hosts;
  final ServerHost? currentHost;
  final Function(List<ServerHost>) onSaveHosts;
  final Function(ServerHost) onSelectHost;

  const HomeScreen({
    Key? key,
    required this.hosts,
    required this.currentHost,
    required this.onSaveHosts,
    required this.onSelectHost,
  }) : super(key: key);

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  Timer? _statusTimer;
  Map<String, dynamic>? _statusData;
  List<String> _quickLogs = [];
  bool _isLoading = false;
  String? _errorMessage;

  @override
  void initState() {
    super.initState();
    _refreshStatus();
    _startStatusPolling();
  }

  @override
  void didUpdateWidget(covariant HomeScreen oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.currentHost?.id != widget.currentHost?.id) {
      _refreshStatus();
    }
  }

  @override
  void dispose() {
    _statusTimer?.cancel();
    super.dispose();
  }

  void _startStatusPolling() {
    _statusTimer?.cancel();
    _statusTimer = Timer.periodic(const Duration(seconds: 3), (_) {
      if (widget.currentHost != null) {
        _refreshStatus(silent: true);
      }
    });
  }

  Future<void> _refreshStatus({bool silent = false}) async {
    if (widget.currentHost == null) return;
    if (!silent) setState(() => _isLoading = true);

    final res = await ApiService.getStatus(widget.currentHost!);
    final logs = await ApiService.getLogs(widget.currentHost!);

    if (mounted) {
      setState(() {
        if (res['success'] == true) {
          _statusData = res['data'];
          _errorMessage = null;
        } else {
          _errorMessage = res['error'] ?? 'Нет связи';
        }
        _quickLogs = logs.length > 5 ? logs.sublist(logs.length - 5) : logs;
        if (!silent) _isLoading = false;
      });
    }
  }

  Future<void> _handleStart() async {
    if (widget.currentHost == null) return;
    setState(() => _isLoading = true);
    final res = await ApiService.startServer(widget.currentHost!);
    if (!mounted) return;
    setState(() => _isLoading = false);

    _showResultSnackbar(res, successMsg: 'Команда на запуск отправлена!');
    _refreshStatus(silent: true);
  }

  Future<void> _handleStop({bool force = false}) async {
    if (widget.currentHost == null) return;
    setState(() => _isLoading = true);
    final res = await ApiService.stopServer(widget.currentHost!, force: force);
    if (!mounted) return;
    setState(() => _isLoading = false);

    _showResultSnackbar(res, successMsg: force ? 'Сервер принудительно остановлен' : 'Команда /stop отправлена!');
    _refreshStatus(silent: true);
  }

  Future<void> _handleRestart() async {
    if (widget.currentHost == null) return;
    setState(() => _isLoading = true);
    final res = await ApiService.restartServer(widget.currentHost!);
    if (!mounted) return;
    setState(() => _isLoading = false);

    _showResultSnackbar(res, successMsg: 'Сервер перезапускается...');
    _refreshStatus(silent: true);
  }

  void _showResultSnackbar(Map<String, dynamic> res, {required String successMsg}) {
    final success = res['success'] == true;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(success ? successMsg : (res['message'] ?? res['error'] ?? 'Ошибка')),
        backgroundColor: success ? Colors.green : Colors.redAccent,
      ),
    );
  }

  String _formatUptime(int seconds) {
    if (seconds <= 0) return '00:00';
    final h = seconds ~/ 3600;
    final m = (seconds % 3600) ~/ 60;
    final s = seconds % 60;
    if (h > 0) {
      return '${h.toString().padLeft(2, '0')}:${m.toString().padLeft(2, '0')}:${s.toString().padLeft(2, '0')}';
    }
    return '${m.toString().padLeft(2, '0')}:${s.toString().padLeft(2, '0')}';
  }

  @override
  Widget build(BuildContext context) {
    final currentHost = widget.currentHost;

    return Scaffold(
      appBar: AppBar(
        title: _buildHostSelector(),
        actions: [
          IconButton(
            icon: const Icon(Icons.help_outline),
            tooltip: 'Инструкция',
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const InstructionsScreen()),
              );
            },
          ),
          IconButton(
            icon: const Icon(Icons.settings),
            tooltip: 'Настройки',
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => SettingsScreen(
                    hosts: widget.hosts,
                    currentHost: widget.currentHost,
                    onSaveHosts: widget.onSaveHosts,
                    onSelectHost: widget.onSelectHost,
                  ),
                ),
              );
            },
          ),
        ],
      ),
      body: currentHost == null ? _buildNoHostsView() : _buildDashboard(currentHost),
    );
  }

  Widget _buildHostSelector() {
    if (widget.hosts.isEmpty) {
      return const Text('Server Control');
    }

    return DropdownButtonHideUnderline(
      child: DropdownButton<String>(
        value: widget.currentHost?.id,
        dropdownColor: const Color(0xFF1E2630),
        icon: const Icon(Icons.arrow_drop_down, color: Colors.greenAccent),
        selectedItemBuilder: (BuildContext context) {
          return widget.hosts.map<Widget>((ServerHost h) {
            return Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Icon(Icons.dns, size: 18, color: Colors.greenAccent),
                const SizedBox(width: 8),
                Text(
                  h.name,
                  style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                ),
              ],
            );
          }).toList();
        },
        items: widget.hosts.map((ServerHost h) {
          return DropdownMenuItem<String>(
            value: h.id,
            child: Row(
              children: [
                Icon(
                  h.id == widget.currentHost?.id ? Icons.check_circle : Icons.computer,
                  color: h.id == widget.currentHost?.id ? Colors.greenAccent : Colors.white70,
                  size: 18,
                ),
                const SizedBox(width: 10),
                Text(h.name),
              ],
            ),
          );
        }).toList(),
        onChanged: (String? newId) {
          if (newId != null) {
            final match = widget.hosts.firstWhere((h) => h.id == newId);
            widget.onSelectHost(match);
          }
        },
      ),
    );
  }

  Widget _buildNoHostsView() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.router, size: 80, color: Colors.greenAccent),
            const SizedBox(height: 16),
            const Text(
              'Нет подключенных серверов',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            const Text(
              'Запустите ServerAgent.exe на компьютере и добавьте адрес сервера для удалённого управления.',
              textAlign: TextAlign.center,
              style: TextStyle(color: Colors.white70),
            ),
            const SizedBox(height: 24),
            ElevatedButton.icon(
              icon: const Icon(Icons.add),
              label: const Text('Добавить сервер'),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.greenAccent.shade700,
                foregroundColor: Colors.black,
                padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
              ),
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => SettingsScreen(
                      hosts: widget.hosts,
                      currentHost: widget.currentHost,
                      onSaveHosts: widget.onSaveHosts,
                      onSelectHost: widget.onSelectHost,
                    ),
                  ),
                );
              },
            ),
            const SizedBox(height: 12),
            TextButton.icon(
              icon: const Icon(Icons.help_outline),
              label: const Text('Открыть инструкцию'),
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => const InstructionsScreen()),
                );
              },
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildDashboard(ServerHost host) {
    final state = _statusData?['state'] ?? 'unknown';
    final isRunning = _statusData?['is_running'] == true;
    final uptime = _statusData?['uptime_seconds'] ?? 0;
    final scriptPath = _statusData?['full_path'] ?? '';
    final scriptExists = _statusData?['script_exists'] ?? true;

    Color statusColor;
    String statusTitle;
    IconData statusIcon;

    if (_errorMessage != null) {
      statusColor = Colors.redAccent;
      statusTitle = 'НЕТ СВЯЗИ С АГЕНТОМ';
      statusIcon = Icons.signal_wifi_connected_no_internet_4;
    } else if (state == 'online') {
      statusColor = Colors.greenAccent;
      statusTitle = 'ОНЛАЙН (РАБОТАЕТ)';
      statusIcon = Icons.check_circle;
    } else if (state == 'starting') {
      statusColor = Colors.amberAccent;
      statusTitle = 'ЗАПУСКАЕТСЯ...';
      statusIcon = Icons.timelapse;
    } else if (state == 'stopping') {
      statusColor = Colors.orangeAccent;
      statusTitle = 'ОСТАНАВЛИВАЕТСЯ...';
      statusIcon = Icons.hourglass_top;
    } else {
      statusColor = Colors.grey.shade400;
      statusTitle = 'ОФФЛАЙН (ВЫКЛЮЧЕН)';
      statusIcon = Icons.pause_circle_outline;
    }

    return RefreshIndicator(
      onRefresh: () => _refreshStatus(),
      child: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          // Карточка статуса
          Card(
            elevation: 4,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(16),
              side: BorderSide(color: statusColor.withOpacity(0.5), width: 1.5),
            ),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                children: [
                  Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.all(10),
                        decoration: BoxDecoration(
                          color: statusColor.withOpacity(0.15),
                          shape: BoxShape.circle,
                        ),
                        child: Icon(statusIcon, color: statusColor, size: 28),
                      ),
                      const SizedBox(width: 14),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              statusTitle,
                              style: TextStyle(
                                color: statusColor,
                                fontWeight: FontWeight.bold,
                                fontSize: 16,
                                letterSpacing: 0.8,
                              ),
                            ),
                            const SizedBox(height: 4),
                            Text(
                              _errorMessage != null
                                  ? _errorMessage!
                                  : (isRunning ? 'Аптайм: ${_formatUptime(uptime)}' : 'Готов к запуску'),
                              style: const TextStyle(fontSize: 13, color: Colors.white70),
                            ),
                          ],
                        ),
                      ),
                      IconButton(
                        icon: const Icon(Icons.refresh),
                        onPressed: () => _refreshStatus(),
                        tooltip: 'Обновить',
                      ),
                    ],
                  ),
                  const Divider(height: 24),
                  Row(
                    children: [
                      const Icon(Icons.folder, size: 16, color: Colors.white54),
                      const SizedBox(width: 8),
                      Expanded(
                        child: Text(
                          scriptPath.isEmpty ? 'Папка не настроена' : scriptPath,
                          style: TextStyle(
                            fontSize: 12,
                            fontFamily: 'monospace',
                            color: scriptExists ? Colors.white70 : Colors.redAccent,
                          ),
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                      TextButton(
                        onPressed: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (_) => SettingsScreen(
                                hosts: widget.hosts,
                                currentHost: widget.currentHost,
                                onSaveHosts: widget.onSaveHosts,
                                onSelectHost: widget.onSelectHost,
                              ),
                            ),
                          );
                        },
                        child: const Text('Сменить', style: TextStyle(fontSize: 12)),
                      ),
                    ],
                  ),
                  if (!scriptExists && _errorMessage == null)
                    const Padding(
                      padding: EdgeInsets.only(top: 4.0),
                      child: Text(
                        '⚠️ Файл запуска не найден! Укажите верную папку через кнопку «Сменить».',
                        style: TextStyle(color: Colors.redAccent, fontSize: 12),
                      ),
                    ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 20),

          // Кнопки управления сервером
          Row(
            children: [
              Expanded(
                child: ElevatedButton.icon(
                  onPressed: isRunning || _errorMessage != null || _isLoading ? null : _handleStart,
                  icon: const Icon(Icons.play_arrow, size: 24),
                  label: const Text('ЗАПУСК', style: TextStyle(fontWeight: FontWeight.bold)),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.greenAccent.shade700,
                    foregroundColor: Colors.black,
                    padding: const EdgeInsets.symmetric(vertical: 16),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                  ),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: ElevatedButton.icon(
                  onPressed: !isRunning || _errorMessage != null || _isLoading ? null : () => _handleStop(),
                  icon: const Icon(Icons.stop, size: 24),
                  label: const Text('СТОП', style: TextStyle(fontWeight: FontWeight.bold)),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.redAccent.shade700,
                    foregroundColor: Colors.white,
                    padding: const EdgeInsets.symmetric(vertical: 16),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          OutlinedButton.icon(
            onPressed: !isRunning || _errorMessage != null || _isLoading ? null : _handleRestart,
            icon: const Icon(Icons.restart_alt),
            label: const Text('ПЕРЕЗАПУСТИТЬ СЕРВЕР'),
            style: OutlinedButton.styleFrom(
              padding: const EdgeInsets.symmetric(vertical: 14),
              foregroundColor: Colors.amberAccent,
              side: const BorderSide(color: Colors.amberAccent),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
            ),
          ),

          const SizedBox(height: 24),

          // Карточка превью логов и перехода в консоль
          Card(
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Row(
                        children: [
                          Icon(Icons.terminal, size: 18, color: Colors.cyanAccent),
                          SizedBox(width: 8),
                          Text('Логи сервера', style: TextStyle(fontWeight: FontWeight.bold)),
                        ],
                      ),
                      TextButton.icon(
                        icon: const Icon(Icons.open_in_new, size: 16),
                        label: const Text('Открыть консоль'),
                        onPressed: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (_) => ConsoleScreen(host: host),
                            ),
                          );
                        },
                      ),
                    ],
                  ),
                  const Divider(),
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      color: const Color(0xFF0F141A),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: _quickLogs.isEmpty
                        ? const Text(
                            'Логи отсутствуют...',
                            style: TextStyle(color: Colors.white38, fontSize: 12),
                          )
                        : Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: _quickLogs.map((l) {
                              return Text(
                                l,
                                style: const TextStyle(
                                  fontFamily: 'monospace',
                                  fontSize: 11,
                                  color: Colors.white70,
                                ),
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                              );
                            }).toList(),
                          ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
