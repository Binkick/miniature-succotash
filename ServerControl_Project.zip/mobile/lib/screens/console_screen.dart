import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../models/server_host.dart';
import '../services/api_service.dart';

class ConsoleScreen extends StatefulWidget {
  final ServerHost host;

  const ConsoleScreen({Key? key, required this.host}) : super(key: key);

  @override
  State<ConsoleScreen> createState() => _ConsoleScreenState();
}

class _ConsoleScreenState extends State<ConsoleScreen> {
  final List<String> _logs = [];
  final TextEditingController _cmdController = TextEditingController();
  final ScrollController _scrollController = ScrollController();
  Timer? _timer;
  bool _autoRefresh = true;
  bool _isLoading = false;

  @override
  void initState() {
    super.initState();
    _fetchLogs();
    _startAutoRefresh();
  }

  @override
  void dispose() {
    _timer?.cancel();
    _cmdController.dispose();
    _scrollController.dispose();
    super.dispose();
  }

  void _startAutoRefresh() {
    _timer?.cancel();
    _timer = Timer.periodic(const Duration(seconds: 2), (_) {
      if (_autoRefresh) {
        _fetchLogs(silent: true);
      }
    });
  }

  Future<void> _fetchLogs({bool silent = false}) async {
    if (!silent) {
      setState(() => _isLoading = true);
    }
    final logs = await ApiService.getLogs(widget.host);
    if (mounted) {
      setState(() {
        _logs.clear();
        _logs.addAll(logs);
        if (!silent) _isLoading = false;
      });
      _scrollToBottom();
    }
  }

  void _scrollToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scrollController.hasClients) {
        _scrollController.jumpTo(_scrollController.position.maxScrollExtent);
      }
    });
  }

  Future<void> _sendCommand() async {
    final text = _cmdController.text.trim();
    if (text.isEmpty) return;

    _cmdController.clear();
    final res = await ApiService.sendCommand(widget.host, text);
    if (!mounted) return;

    if (res['success'] == true) {
      _fetchLogs(silent: true);
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(res['error'] ?? 'Ошибка отправки команды'),
          backgroundColor: Colors.redAccent,
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Консоль: ${widget.host.name}'),
        actions: [
          IconButton(
            icon: Icon(_autoRefresh ? Icons.pause_circle_filled : Icons.play_circle_filled),
            tooltip: _autoRefresh ? 'Пауза авто-обновления' : 'Возобновить авто-обновление',
            onPressed: () {
              setState(() => _autoRefresh = !_autoRefresh);
            },
          ),
          IconButton(
            icon: const Icon(Icons.refresh),
            tooltip: 'Обновить логи',
            onPressed: () => _fetchLogs(),
          ),
          IconButton(
            icon: const Icon(Icons.copy),
            tooltip: 'Скопировать все логи',
            onPressed: () {
              Clipboard.setData(ClipboardData(text: _logs.join('\n')));
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('Логи скопированы в буфер')),
              );
            },
          ),
        ],
      ),
      body: Column(
        children: [
          if (_isLoading)
            const LinearProgressIndicator(minHeight: 2),
          Expanded(
            child: Container(
              color: const Color(0xFF0F141A),
              padding: const EdgeInsets.all(12),
              child: _logs.isEmpty
                  ? const Center(
                      child: Text(
                        'Логов пока нет. Запустите сервер для вывода сообщений.',
                        style: TextStyle(color: Colors.white54, fontSize: 13),
                      ),
                    )
                  : ListView.builder(
                      controller: _scrollController,
                      itemCount: _logs.length,
                      itemBuilder: (context, index) {
                        final line = _logs[index];
                        Color color = Colors.white70;
                        if (line.contains('ERROR') || line.contains('Exception')) {
                          color = Colors.redAccent;
                        } else if (line.contains('WARN')) {
                          color = Colors.amberAccent;
                        } else if (line.contains('[AGENT]')) {
                          color = Colors.cyanAccent;
                        } else if (line.contains('[COMMAND]')) {
                          color = Colors.greenAccent;
                        }

                        return Padding(
                          padding: const EdgeInsets.symmetric(vertical: 2.0),
                          child: Text(
                            line,
                            style: TextStyle(
                              fontFamily: 'monospace',
                              fontSize: 12,
                              color: color,
                            ),
                          ),
                        );
                      },
                    ),
            ),
          ),
          Container(
            color: const Color(0xFF1E2630),
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            child: SafeArea(
              child: Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: _cmdController,
                      style: const TextStyle(color: Colors.white, fontFamily: 'monospace'),
                      decoration: InputDecoration(
                        hintText: 'Введите команду (например: op Steve, /say Привет)...',
                        hintStyle: const TextStyle(color: Colors.white38, fontSize: 13),
                        contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                        filled: true,
                        fillColor: const Color(0xFF131820),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(8),
                          borderSide: BorderSide.none,
                        ),
                      ),
                      onSubmitted: (_) => _sendCommand(),
                    ),
                  ),
                  const SizedBox(width: 8),
                  IconButton.filled(
                    onPressed: _sendCommand,
                    icon: const Icon(Icons.send),
                    style: IconButton.styleFrom(
                      backgroundColor: Colors.greenAccent.shade700,
                      foregroundColor: Colors.black,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
