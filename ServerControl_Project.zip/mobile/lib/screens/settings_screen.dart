import 'package:flutter/material.dart';
import '../models/server_host.dart';
import '../services/api_service.dart';

class SettingsScreen extends StatefulWidget {
  final List<ServerHost> hosts;
  final ServerHost? currentHost;
  final Function(List<ServerHost>) onSaveHosts;
  final Function(ServerHost) onSelectHost;

  const SettingsScreen({
    Key? key,
    required this.hosts,
    required this.currentHost,
    required this.onSaveHosts,
    required this.onSelectHost,
  }) : super(key: key);

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  late List<ServerHost> _hosts;
  final TextEditingController _serverDirController = TextEditingController();
  final TextEditingController _launchFileController = TextEditingController();
  bool _isLoadingSettings = false;

  @override
  void initState() {
    super.initState();
    _hosts = List.from(widget.hosts);
    _loadRemoteSettings();
  }

  @override
  void dispose() {
    _serverDirController.dispose();
    _launchFileController.dispose();
    super.dispose();
  }

  Future<void> _loadRemoteSettings() async {
    if (widget.currentHost == null) return;
    setState(() => _isLoadingSettings = true);
    final res = await ApiService.getStatus(widget.currentHost!);
    if (mounted) {
      if (res['success'] == true) {
        final data = res['data'];
        _serverDirController.text = data['server_dir'] ?? '';
        _launchFileController.text = data['launch_file'] ?? 'start.bat';
      }
      setState(() => _isLoadingSettings = false);
    }
  }

  Future<void> _saveRemoteSettings() async {
    if (widget.currentHost == null) return;
    final dir = _serverDirController.text.trim();
    final file = _launchFileController.text.trim();

    setState(() => _isLoadingSettings = true);
    final res = await ApiService.updateSettings(
      widget.currentHost!,
      serverDir: dir,
      launchFile: file.isEmpty ? 'start.bat' : file,
    );
    if (!mounted) return;
    setState(() => _isLoadingSettings = false);

    if (res['success'] == true) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Папка сервера успешно обновлена на ПК!'),
          backgroundColor: Colors.green,
        ),
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(res['error'] ?? 'Ошибка сохранения'),
          backgroundColor: Colors.redAccent,
        ),
      );
    }
  }

  void _showAddEditHostDialog([ServerHost? hostToEdit]) {
    final nameCtrl = TextEditingController(text: hostToEdit?.name ?? '');
    final addrCtrl = TextEditingController(text: hostToEdit?.address ?? '');
    final tokenCtrl = TextEditingController(text: hostToEdit?.token ?? '');

    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(hostToEdit == null ? 'Добавить сервер' : 'Редактировать сервер'),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: nameCtrl,
                decoration: const InputDecoration(
                  labelText: 'Название (например: Мой ПК, Сервер друга)',
                  border: OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: addrCtrl,
                decoration: const InputDecoration(
                  labelText: 'Адрес ngrok',
                  hintText: 'https://eradicate-book-activist.ngrok-free.dev',
                  border: OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: tokenCtrl,
                decoration: const InputDecoration(
                  labelText: 'Токен из окна ServerAgent на ПК',
                  border: OutlineInputBorder(),
                ),
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Отмена'),
          ),
          ElevatedButton(
            onPressed: () {
              final name = nameCtrl.text.trim();
              final addr = addrCtrl.text.trim();
              final token = tokenCtrl.text.trim();

              if (name.isEmpty || addr.isEmpty || token.isEmpty) {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Пожалуйста, заполните все поля')),
                );
                return;
              }

              setState(() {
                if (hostToEdit != null) {
                  hostToEdit.name = name;
                  hostToEdit.address = addr;
                  hostToEdit.token = token;
                } else {
                  final newHost = ServerHost(
                    id: DateTime.now().millisecondsSinceEpoch.toString(),
                    name: name,
                    address: addr,
                    token: token,
                  );
                  _hosts.add(newHost);
                  if (_hosts.length == 1) {
                    widget.onSelectHost(newHost);
                  }
                }
              });

              widget.onSaveHosts(_hosts);
              Navigator.pop(ctx);
            },
            child: const Text('Сохранить'),
          ),
        ],
      ),
    );
  }

  void _deleteHost(ServerHost host) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Удалить сервер?'),
        content: Text('Удалить "${host.name}" из списка?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Отмена'),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: Colors.redAccent),
            onPressed: () {
              setState(() {
                _hosts.removeWhere((h) => h.id == host.id);
                if (widget.currentHost?.id == host.id && _hosts.isNotEmpty) {
                  widget.onSelectHost(_hosts.first);
                }
              });
              widget.onSaveHosts(_hosts);
              Navigator.pop(ctx);
            },
            child: const Text('Удалить'),
          ),
        ],
      ),
    );
  }

  Future<void> _testHostConnection(ServerHost host) async {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('Проверка связи с ${host.name}...'), duration: const Duration(seconds: 1)),
    );
    final ok = await ApiService.ping(host);
    if (!mounted) return;
    if (ok) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Успешно! Связь с ${host.name} установлена.'),
          backgroundColor: Colors.green,
        ),
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Не удалось связаться с ${host.name}. Проверьте ngrok и работу ServerAgent на ПК.'),
          backgroundColor: Colors.redAccent,
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final activeHost = widget.currentHost;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Настройки'),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text(
                'Подключенные серверы (ПК)',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
              IconButton.filled(
                icon: const Icon(Icons.add),
                tooltip: 'Добавить сервер',
                onPressed: () => _showAddEditHostDialog(),
              ),
            ],
          ),
          const SizedBox(height: 8),
          if (_hosts.isEmpty)
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  children: [
                    const Text('Серверы пока не добавлены'),
                    const SizedBox(height: 8),
                    ElevatedButton.icon(
                      onPressed: () => _showAddEditHostDialog(),
                      icon: const Icon(Icons.add),
                      label: const Text('Добавить первый сервер'),
                    ),
                  ],
                ),
              ),
            )
          else
            ..._hosts.map((h) {
              final isCurrent = h.id == activeHost?.id;
              return Card(
                elevation: isCurrent ? 3 : 1,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                  side: isCurrent
                      ? const BorderSide(color: Colors.greenAccent, width: 2)
                      : BorderSide.none,
                ),
                child: ListTile(
                  title: Text(h.name, style: const TextStyle(fontWeight: FontWeight.bold)),
                  subtitle: Text(h.address),
                  leading: Icon(
                    isCurrent ? Icons.check_circle : Icons.computer,
                    color: isCurrent ? Colors.greenAccent : Colors.white54,
                  ),
                  trailing: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      IconButton(
                        icon: const Icon(Icons.network_check, color: Colors.cyanAccent),
                        tooltip: 'Проверить связь',
                        onPressed: () => _testHostConnection(h),
                      ),
                      IconButton(
                        icon: const Icon(Icons.edit, color: Colors.white70),
                        tooltip: 'Редактировать',
                        onPressed: () => _showAddEditHostDialog(h),
                      ),
                      IconButton(
                        icon: const Icon(Icons.delete_outline, color: Colors.redAccent),
                        tooltip: 'Удалить',
                        onPressed: () => _deleteHost(h),
                      ),
                    ],
                  ),
                  onTap: () {
                    widget.onSelectHost(h);
                    setState(() {});
                  },
                ),
              );
            }).toList(),
          const SizedBox(height: 24),
          const Divider(),
          const SizedBox(height: 8),
          Text(
            'Настройка папки для: ${activeHost?.name ?? "нет сервера"}',
            style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 8),
          const Text(
            'Вы можете изменить путь к папке сервера прямо отсюда. Агент на ПК сразу переключится на неё.',
            style: TextStyle(color: Colors.white70, fontSize: 13),
          ),
          const SizedBox(height: 16),
          TextField(
            controller: _serverDirController,
            decoration: const InputDecoration(
              labelText: 'Путь к папке сервера на ПК',
              hintText: 'например: C:\\Games\\MinecraftServer или D:\\Servers\\vanilla',
              border: OutlineInputBorder(),
              prefixIcon: Icon(Icons.folder_open),
            ),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _launchFileController,
            decoration: const InputDecoration(
              labelText: 'Имя файла запуска',
              hintText: 'start.bat (или run.bat)',
              border: OutlineInputBorder(),
              prefixIcon: Icon(Icons.play_arrow),
            ),
          ),
          const SizedBox(height: 16),
          ElevatedButton.icon(
            onPressed: _isLoadingSettings || activeHost == null ? null : _saveRemoteSettings,
            icon: _isLoadingSettings
                ? const SizedBox(
                    width: 16,
                    height: 16,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  )
                : const Icon(Icons.save),
            label: const Text('Применить путь к папке на ПК'),
            style: ElevatedButton.styleFrom(
              padding: const EdgeInsets.symmetric(vertical: 14),
              backgroundColor: Colors.greenAccent.shade700,
              foregroundColor: Colors.black,
            ),
          ),
        ],
      ),
    );
  }
}
