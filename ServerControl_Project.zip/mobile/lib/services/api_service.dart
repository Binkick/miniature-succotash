import 'dart:convert';
import 'dart:async';
import 'package:http/http.dart' as http;
import '../models/server_host.dart';

class ApiService {
  static const Duration timeoutDuration = Duration(seconds: 8);

  static Map<String, String> _headers(String token) {
    return {
      'Content-Type': 'application/json; charset=utf-8',
      'X-Auth-Token': token,
      'ngrok-skip-browser-warning': 'true',
      'User-Agent': 'MineServerControlApp/3.0',
    };
  }

  static Future<bool> ping(ServerHost host) async {
    try {
      final url = Uri.parse('${host.cleanBaseUrl}/api/ping');
      final res = await http.get(
        url,
        headers: {
          'ngrok-skip-browser-warning': 'true',
          'User-Agent': 'MineServerControlApp/3.0',
        },
      ).timeout(timeoutDuration);

      if (res.statusCode == 200) {
        final data = json.decode(utf8.decode(res.bodyBytes));
        return data['success'] == true;
      }
    } catch (_) {}
    return false;
  }

  static Future<Map<String, dynamic>> getStatus(ServerHost host) async {
    try {
      final url = Uri.parse('${host.cleanBaseUrl}/api/status');
      final res = await http.get(url, headers: _headers(host.token)).timeout(timeoutDuration);
      if (res.statusCode == 200) {
        final data = json.decode(utf8.decode(res.bodyBytes));
        return {'success': true, 'data': data['data']};
      } else if (res.statusCode == 401) {
        return {'success': false, 'error': 'Неверный токен авторизации'};
      }
      return {'success': false, 'error': 'Ошибка сервера (${res.statusCode})'};
    } catch (e) {
      return {'success': false, 'error': 'Нет связи с ПК (${e.toString()})'};
    }
  }

  static Future<Map<String, dynamic>> startServer(ServerHost host) async {
    try {
      final url = Uri.parse('${host.cleanBaseUrl}/api/start');
      final res = await http.post(url, headers: _headers(host.token)).timeout(timeoutDuration);
      final data = json.decode(utf8.decode(res.bodyBytes));
      return data;
    } catch (e) {
      return {'success': false, 'error': e.toString()};
    }
  }

  static Future<Map<String, dynamic>> stopServer(ServerHost host, {bool force = false}) async {
    try {
      final url = Uri.parse('${host.cleanBaseUrl}/api/stop');
      final res = await http.post(
        url,
        headers: _headers(host.token),
        body: json.encode({'force': force}),
      ).timeout(timeoutDuration);
      final data = json.decode(utf8.decode(res.bodyBytes));
      return data;
    } catch (e) {
      return {'success': false, 'error': e.toString()};
    }
  }

  static Future<Map<String, dynamic>> restartServer(ServerHost host) async {
    try {
      final url = Uri.parse('${host.cleanBaseUrl}/api/restart');
      final res = await http.post(url, headers: _headers(host.token)).timeout(timeoutDuration);
      final data = json.decode(utf8.decode(res.bodyBytes));
      return data;
    } catch (e) {
      return {'success': false, 'error': e.toString()};
    }
  }

  static Future<Map<String, dynamic>> sendCommand(ServerHost host, String command) async {
    try {
      final url = Uri.parse('${host.cleanBaseUrl}/api/command');
      final res = await http.post(
        url,
        headers: _headers(host.token),
        body: json.encode({'command': command}),
      ).timeout(timeoutDuration);
      final data = json.decode(utf8.decode(res.bodyBytes));
      return data;
    } catch (e) {
      return {'success': false, 'error': e.toString()};
    }
  }

  static Future<List<String>> getLogs(ServerHost host) async {
    try {
      final url = Uri.parse('${host.cleanBaseUrl}/api/logs');
      final res = await http.get(url, headers: _headers(host.token)).timeout(timeoutDuration);
      if (res.statusCode == 200) {
        final data = json.decode(utf8.decode(res.bodyBytes));
        final logs = data['logs'] as List<dynamic>?;
        return logs?.map((e) => e.toString()).toList() ?? [];
      }
    } catch (_) {}
    return [];
  }

  static Future<Map<String, dynamic>> updateSettings(
    ServerHost host, {
    String? serverDir,
    String? launchFile,
  }) async {
    try {
      final url = Uri.parse('${host.cleanBaseUrl}/api/settings');
      final body = <String, dynamic>{};
      if (serverDir != null) body['server_dir'] = serverDir;
      if (launchFile != null) body['launch_file'] = launchFile;

      final res = await http.post(
        url,
        headers: _headers(host.token),
        body: json.encode(body),
      ).timeout(timeoutDuration);
      final data = json.decode(utf8.decode(res.bodyBytes));
      return data;
    } catch (e) {
      return {'success': false, 'error': e.toString()};
    }
  }
}
