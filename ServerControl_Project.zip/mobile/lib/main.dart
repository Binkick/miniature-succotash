import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'models/server_host.dart';
import 'screens/home_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const ServerControlApp());
}

class ServerControlApp extends StatefulWidget {
  const ServerControlApp({Key? key}) : super(key: key);

  @override
  State<ServerControlApp> createState() => _ServerControlAppState();
}

class _ServerControlAppState extends State<ServerControlApp> {
  List<ServerHost> _hosts = [];
  ServerHost? _currentHost;
  bool _isLoaded = false;

  @override
  void initState() {
    super.initState();
    _loadStoredHosts();
  }

  Future<void> _loadStoredHosts() async {
    final prefs = await SharedPreferences.getInstance();
    final rawHosts = prefs.getStringList('saved_server_hosts') ?? [];
    final selectedId = prefs.getString('selected_server_id');

    final loaded = rawHosts.map((s) => ServerHost.fromJson(s)).toList();
    ServerHost? current;
    if (loaded.isNotEmpty) {
      current = loaded.firstWhere(
        (h) => h.id == selectedId,
        orElse: () => loaded.first,
      );
    }

    setState(() {
      _hosts = loaded;
      _currentHost = current;
      _isLoaded = true;
    });
  }

  Future<void> _saveHosts(List<ServerHost> hosts) async {
    final prefs = await SharedPreferences.getInstance();
    final encoded = hosts.map((h) => h.toJson()).toList();
    await prefs.setStringList('saved_server_hosts', encoded);
    setState(() {
      _hosts = hosts;
    });
  }

  Future<void> _selectHost(ServerHost host) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('selected_server_id', host.id);
    setState(() {
      _currentHost = host;
    });
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Server Control',
      debugShowCheckedModeBanner: false,
      themeMode: ThemeMode.dark,
      darkTheme: ThemeData(
        useMaterial3: true,
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF10141C),
        colorScheme: ColorScheme.dark(
          primary: Colors.greenAccent.shade400,
          secondary: Colors.cyanAccent.shade400,
          surface: const Color(0xFF181F2A),
          background: const Color(0xFF10141C),
        ),
        appBarTheme: const AppBarTheme(
          backgroundColor: Color(0xFF151B24),
          elevation: 0,
          centerTitle: false,
        ),
        cardTheme: CardTheme(
          color: const Color(0xFF1A222E),
          elevation: 2,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
        ),
      ),
      home: _isLoaded
          ? HomeScreen(
              hosts: _hosts,
              currentHost: _currentHost,
              onSaveHosts: _saveHosts,
              onSelectHost: _selectHost,
            )
          : const Scaffold(
              body: Center(
                child: CircularProgressIndicator(color: Colors.greenAccent),
              ),
            ),
    );
  }
}
