import 'dart:convert';

class ServerHost {
  final String id;
  String name;
  String address; // e.g. "eradicate-book-activist.ngrok-free.dev"
  String token;

  ServerHost({
    required this.id,
    required this.name,
    required this.address,
    required this.token,
  });

  String get cleanBaseUrl {
    var addr = address.trim();
    if (!addr.startsWith('http://') && !addr.startsWith('https://')) {
      // Для ngrok по умолчанию используем безопасный https
      addr = 'https://$addr';
    }
    if (addr.endsWith('/')) {
      addr = addr.substring(0, addr.length - 1);
    }
    return addr;
  }

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'name': name,
      'address': address,
      'token': token,
    };
  }

  factory ServerHost.fromMap(Map<String, dynamic> map) {
    return ServerHost(
      id: map['id'] ?? '',
      name: map['name'] ?? 'Сервер',
      address: map['address'] ?? '',
      token: map['token'] ?? '',
    );
  }

  String toJson() => json.encode(toMap());

  factory ServerHost.fromJson(String source) => ServerHost.fromMap(json.decode(source));
}
